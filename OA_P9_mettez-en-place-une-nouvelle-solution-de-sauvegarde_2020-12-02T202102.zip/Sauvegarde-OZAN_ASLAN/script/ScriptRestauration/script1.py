#!/usr/bin/python3

import sys
import os
import time
import glob
import stat


from datetime import datetime

# Récupération de la date du jour
da = (datetime.now().date())

# Décompression de archives compresser dans le fichie bk
os.system (" tar -xzvf /home/user/op/backup/wordpress-web-backup." +  str(da) + ".tar.gz -C /home/user/op/bk")
# Copie de la sauvegarde  wordpress dans le fichier /var/www/html
os.system (" sudo cp -r  /home/user/op/bk/var/www/html/wordpress   /var/www/html")
# Mettre les droit de utilisateur www-data.www-data  sur le fichier wordpress copié
os.system ("sudo chown www-data.www-data /var/www/html/wordpress/* -R")
# Faire une restauration de la base de donné 
os.system ("mysql -u wpuser -pwppassword wordpress <  /home/user/op/backup/wordpress-backup." + str(da) +".sql")
# redemarrer le service apache
os.system ("sudo service apache2 restart")




