#!/usr/bin/python3

import sys
import os
import time
from datetime import datetime

da = (datetime.now().date())




#Aller dans le fichier op
os.system ("cd /home/user/op")

#faire une sauvegarde de la base de donnée wordpress avec la date inclu dans le nom de la sauvegarde , dans le fichier op
os.system ("mysqldump -u wpuser -pwppassword  wordpress > wordpress-backup." + str(da) +".sql ")

#faire une archive compréssée du fichier wordpress incluant la date du jour dans son nom , dans le ficier op
os.system ("tar -czvf wordpress-web-backup." + str(da) + ".tar.gz /var/www/html/wordpress")

#envoi avec sftp le wordpress compressé avec la clé id_rsa pour ne pas avoir a mettre de mot de passe 
os.system (" echo 'put' /home/user/op/wordpress-web-backup." + str(da) + ".tar.gz  | sftp -i /home/user/.ssh/id_rsa   user@192.168.1.2:/home/user/op/backup")

#envoi avec sftp la base de donnée de wordpress  avec la id_rsa pour ne pas avoir a mettre de mot de passe
os.system (" echo 'put' /home/user/op/wordpress-backup." + str(da) + ".sql | sftp -i /home/user/.ssh/id_rsa   user@192.168.1.2:/home/user/op/backup")

#Supprimer les fichier du dossier backup qui datte  de plus d'une semaine (604800 seconde) 
one_week_ago = time.time() - 604800
folder = "/home/user/op/"
os.chdir(folder)
for somefile in os.listdir('.'):
        mtime=os.path.getmtime(somefile)
        if mtime < one_week_ago:
        	os.unlink(somefile)